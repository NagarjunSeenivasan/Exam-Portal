<?php
session_start();
require 'includes/connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $adminType = $_POST['adminType']; // 'Admin' or 'BranchAdmin'

    $collection = $db->$adminType;

    // Find admin by username
    $admin = $collection->findOne(['username' => $username]);

    if ($admin && password_verify($password, $admin['password'])) {
        // Start session and set session variables
        $_SESSION['username'] = $username;
        // $_SESSION['companyId'] = $admin['companyId'];
        $_SESSION['type'] = $adminType;

        // Redirect to dashboard
        header("Location: dashboard.php");
        exit;
    } else {
        // Invalid login credentials
        $errorMessage = "Invalid login credentials.";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f6fb;
            font-family: Poppins;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
            /* color: #fff; */
        }
        .card {
            background: #fff;
            color: #333;
            border-radius: 15px;
            /* box-shadow: ; */
            padding: 30px;
            width: 100%;
            max-width: 400px;
        }
        .card-header {
            background: linear-gradient(135deg,#ff914d, #ff914d);
            color: #fff;
            text-align: center;
            font-size: 1.5rem;
            font-weight: bold;
            border-radius: 15px 15px 0 0;
            padding: 15px 10px;
        }
        .form-control {
            border-radius: 5px;
            /* box-shadow: ; */
        }
        .btn-primary {
            background: #ff914d;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            width: 100%;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #0056b3, #007bff);
        }
        .form-select {
            border-radius: 10px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
            color:#d2e3fc ;
        }
        .footer a {
            color: #d2e3fc;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="card-header">Admin Login</div>
        
        <div class="card-body">
            <form method="POST" action="">
                <div class="mb-3">
                    <label for="username" class="form-label">Username:</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="adminType" class="form-label">Admin Type:</label>
                    <select id="adminType" name="adminType" class="form-select" required>
                        <option value="Admin">Main Admin</option>
                        <!-- <option value="BranchAdmin">Branch Admin</option> -->
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>
        <!-- Display Error Message if Login fails -->
        <?php if (!empty($errorMessage)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($errorMessage); ?>
            </div>
        <?php endif; ?>
        <div class="footer">
            <p>© <?php echo date("Y"); ?> CADIBAL. All Rights Reserved.</p>
            <!-- <p><a href="#">Need Help?</a></p> -->
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
