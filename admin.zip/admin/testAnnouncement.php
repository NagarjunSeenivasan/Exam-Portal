<?php
require 'includes/vendor/autoload.php';

$client = new MongoDB\Client("mongodb+srv://cadibal:Nevinotech512@cadibal.asets.mongodb.net/");
$collection = $client->mcq->announcements;

// Handle Insert Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $title = trim($_POST['title']);
    $description = $_POST['description'];
    $date = $_POST['date'];
    
    // Generate a random string ID for the hidden field
    $randomId = bin2hex(random_bytes(16)); // Generates a 32-character hexadecimal string

    $collection->insertOne([
        'title' => $title,
        'description' => $description,
        'date' => $date,
        'random_id' => $randomId // Save the random ID in MongoDB
    ]);

    echo "<div class='alert alert-success'>Announcement added successfully!</div>";
}

// Handle Delete Request (No ObjectId class)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = $_POST['id']; // Random ID passed from the hidden field

    // Delete using the random_id directly
    $collection->deleteOne(['random_id' => $id]);

    echo "<div class='alert alert-danger'>Announcement deleted successfully!</div>";
}

// Fetch All Announcements
$announcements = $collection->find([], ['sort' => ['date' => -1]]);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Announcements</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Poppins;
            background-color: #D2E3FC;
            color: #37474F;
            padding: 20px;
        }
        .form-section {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .btn-primary {
            background-color: #FF914D;
            border: none;
        }
        .btn-primary:hover {
            background-color: #D2E3FC;
            color: #FF914D;
            border: 1px solid #FF914D;
        }
        table {
            background: #FFFFFF;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table th {
            background-color: #FF914D;
            color: #FFFFFF;
            text-align: center;
        }
        table td {
            text-align: center;
            vertical-align: middle;
        }
        .delete-button {
            background-color: red;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
        }
        .delete-button:hover {
            background-color: darkred;
        }
        .dashboard-button {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
<a href="dashboard.php" class="btn btn-secondary dashboard-button">Go to Dashboard</a>

    <h1 class="text-center mb-4">Manage Announcements</h1>

    <div class="form-section">
        <h2 class="mb-3">Add New Announcement</h2>
        <form method="POST" action="">
            <input type="hidden" name="action" value="add">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" id="title" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea id="description" name="description" class="form-control" rows="4" required></textarea>
            </div>
            <div class="mb-3">
                <label for="date" class="form-label">Date</label>
                <input type="date" id="date" name="date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Add Announcement</button>
        </form>
    </div>

    <h2 class="mb-3">Existing Announcements</h2>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($announcements as $announcement): ?>
                <tr>
                    <td><?php echo htmlspecialchars($announcement['title']); ?></td>
                    <td><?php echo htmlspecialchars($announcement['description']); ?></td>
                    <td><?php echo htmlspecialchars($announcement['date']); ?></td>
                    <td>
                        <form method="POST" action="" style="display: inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?php echo $announcement['random_id']; ?>">
                            <button type="submit" class="delete-button">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
