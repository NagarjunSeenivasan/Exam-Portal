<?php
// MongoDB connection
require 'vendor/autoload.php'; // Include MongoDB PHP library

$client = new MongoDB\Client("mongodb+srv://cadibal:Nevinotech512@cadibal.asets.mongodb.net/");
$db = $client->mcq;
?>
