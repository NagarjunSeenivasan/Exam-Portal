<?php
session_start();
include 'includes/connect.php';

if ($_SESSION['type'] == 'main') {
    echo "<div class='alert alert-danger text-center'>Access Denied.</div>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $type = $_POST['type']; // 'Admin' or 'BranchAdmin'

    $collection = $db->$type;
    $collection->insertOne(['username' => $username, 'password' => $password, 'type' => $type]);

    echo "<div class='alert alert-success text-center'>Admin added successfully.</div>";
}

// Fetch existing users
$type = 'Admin'; // Adjust as needed
$collection = $db->$type;
$users = $collection->find();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_user'])) {
    $usernameToDelete = $_POST['username'];
    $collection->deleteOne(['username' => $usernameToDelete]);
    echo "<div class='alert alert-success text-center'>User deleted successfully.</div>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #74ebd5, #acb6e5);
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: poppins;
        }
        .card {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            border-radius: 15px;
            overflow: hidden;
            background: white;
            padding: 20px;
            transition: transform 0.3s;
            margin-bottom: 20px;
        }
        .card:hover {
            transform: scale(1.02);
        }
        h2 {
            font-weight: bold;
            color: #333;
        }
        .btn-primary {
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            border: none;
            font-size: 16px;
            font-weight: bold;
        }
        .btn-primary:hover {
            background: linear-gradient(45deg, #2a5298, #1e3c72);
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px;
            font-size: 14px;
        }
        .user-list {
            margin-top: 20px;
            width: 100%;
        }
        .table {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .dashboard-button {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <br>
    <div class="container">
    <a href="dashboard.php" class="btn btn-secondary dashboard-button">Go to Dashboard</a>

        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <h2 class="text-center mb-4">Add Admin</h2>
                    <form method="POST" action="">
                        <input type="hidden" name="submit">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username:</label>
                            <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                        </div>
                        <div class="mb-3">
                            <label for="type" class="form-label">Select Role:</label>
                            <select class="form-select" id="type" name="type" required>
                                <option value="Admin">Main Admin</option>
                            </select>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Add Admin</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="user-list">
            <h2 class="text-center">Existing Users</h2>
            <table class="table table-striped table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>Username</th>
                        <th>Type</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?php echo $user['username']; ?></td>
                            <td><?php echo $user['type']; ?></td>
                            <td>
                                <form method="POST" action="" style="display: inline;">
                                    <input type="hidden" name="delete_user"> 
                                    <input type="hidden" name="username" value="<?php echo $user['username']; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
