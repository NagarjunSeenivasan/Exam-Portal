<?php
session_start();
include 'includes/connect.php';
// Check if the user is logged in as Main Admin
if (!isset($_SESSION['username']) || $_SESSION['type'] !== 'Admin') {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['username'];
// $companyId = $_SESSION['companyId'];
try {
    // Fetch counts from collections
    $adminCount = $db->Admin->countDocuments();
    $announcementCount = $db->announcements->countDocuments();
    $branchAdminCount = $db->BranchAdmin->countDocuments();
} catch (Exception $e) {
    $adminCount = $announcementCount = $branchAdminCount = 0;
    error_log('Error fetching counts: ' . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Admin Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #D2E3FC;
            font-family: Poppins, sans-serif;
            color: #37474F;
            min-height: 100vh;
            margin: 0;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background-color: #D2E3FC;
            color: #37474F;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-size: 1.7rem;
            font-weight: bold;
        }
        .navbar .btn {
            color: #37474F;
        }
        .dashboard-header {
            background: linear-gradient(135deg, #FF914D, #FF914D);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            border-radius: 10px;
            margin: 20px;
        }
        .dashboard-header h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }
        .card {
            align-items: center;
            border-radius: 15px;
            padding: 20px;
            margin: 20px;
            background-color: #FFFFFF;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
        }
        .btn {
            border-radius: 10px;
            font-weight: bold;
        }
        .btn-primary {
            background-color: #FF914D;
            color: #FFFFFF;
            border: none;
        }
        .btn-primary:hover {
            background-color: #D2E3FC;
            border: 1px solid #FF914D;
            color: #FF914D;
        }
        footer {
            margin-top: auto;
            text-align: center;
            padding: 20px 0px 0px 0px;
            background-color: #37474F;
            color: #FFFFFF;
            font-size: 0.9rem;
        }
        .icon {
            font-size: 3rem;
            color: #FF914D;
        }
        .card-title {
            color: #37474F;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .card-text {
            color: #6c757d;
            font-size: 1rem;
        }
        .stats {
            text-align: center;
            background: #FFFFFF;
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .stats h2 {
            font-size: 2rem;
            font-weight: bold;
        }
        .stats p {
            font-size: 1rem;
            color: #6c757d;
        }
        .stats .stat-icon {
            font-size: 2.5rem;
            color: #FF914D;
        }
    </style>
</head>
<body>



<div class="dashboard-header">
    <h1>Welcome, <?php echo htmlspecialchars($username); ?>!</h1>
    <p>Manage your company efficiently with advanced tools.</p>
</div>

<div class="container">
    <div class="stats row">
        <div class="col-md-4">
            <div>
            <img src="images/icon/users.gif" width="90px">
                <h2><?php echo $branchAdminCount; ?></h2>
                <p>Total Admins</p>
            </div>
        </div>
        <div class="col-md-4">
            <div>
            <img src="images/icon/notification.gif" width="90px">
                <h2><?php echo $announcementCount; ?></h2>
                <p>Announcements</p>
            </div>
        </div>
        <div class="col-md-4">
            <div>
            <img src="images/icon/total.gif" width="90px">
                <h2><?php echo $adminCount; ?></h2>
                <p>Main Categories</p>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card text-center">
                <img src="images/icon/admin.gif" width="90px">
                <h5 class="card-title">Add Branch Admin</h5>
                <p class="card-text">Create new admins for branch or company management.</p>
                <button class="btn btn-primary" onclick="location.href='addAdmin.php';">Manage Branch Admin</button>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-center">
            <img src="images/icon/branch.gif" width="90px">
                <h5 class="card-title">Add Main</h5>
                <p class="card-text">Create main categories for your company.</p>
                <button class="btn btn-secondary" onclick="location.href='addMain.php';">Manage Main Admin</button>
            </div>
        </div>
    </div>
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card text-center">
            <img src="images/icon/announcement.gif" width="90px">
                <h5 class="card-title">Announcement</h5>
                <p class="card-text">Send a announcement to all users.</p>
                <button class="btn btn-success" onclick="location.href='testAnnouncement.php';">Manage Announcement</button>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card text-center">
            <img src="images/icon/logout.gif" width="90px">
                <h5 class="card-title">Logout</h5>
                <p class="card-text">Logout from the current session.</p>
                <button class="btn btn-danger" onclick="location.href='logout.php';"> Terminate</button>
            </div>
        </div>
    </div>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> CADIBAL. All Rights Reserved.</p>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>
</html>
