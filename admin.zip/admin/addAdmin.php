<?php
session_start();
require 'includes/connect.php';

if ($_SESSION['type'] == 'main') {
    echo "<div class='alert alert-danger text-center'>Access Denied.</div>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $companyid = $_POST['companyId'];
        $usercount = $_POST['usercount'];
        $type = $_POST['type']; // 'Admin' or 'BranchAdmin'

        $collection = $db->$type;
        $collection->insertOne([
            'username' => $username,
            'password' => $password,
            'companyId' => $companyid,
            'usercount' => $usercount,
            'type' => $type
        ]);

        echo "<div class='alert alert-success text-center'>Admin added successfully.</div>";
    } elseif (isset($_POST['delete_user'])) {
        $usernameToDelete = $_POST['delete_user'];
        $collection = $db->BranchAdmin;
        $collection->deleteOne(['username' => $usernameToDelete]);

        echo "<div class='alert alert-success text-center'>User deleted successfully.</div>";
    }
}

// Fetch existing BranchAdmin users
$collection = $db->BranchAdmin;
$users = $collection->find();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Admin</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Poppins, sans-serif;
            background-color: #D2E3FC;
            color: #37474F;
            padding: 20px;
        }
        .form-section {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        .btn-primary {
            background-color: #FF914D;
            border: none;
        }
        .btn-primary:hover {
            background-color: #D2E3FC;
            color: #FF914D;
            border: 1px solid #FF914D;
        }
        .user-list {
            margin-top: 30px;
        }
        .dashboard-button {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
<a href="dashboard.php" class="btn btn-secondary dashboard-button">Go to Dashboard</a>

    <h1 class="text-center mb-4">Add Branch Admin</h1>

    <div class="form-section">
        <form method="POST" action="">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="companyId" class="form-label">Company ID</label>
                <input type="text" id="companyId" name="companyId" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="usercount" class="form-label">User Count</label>
                <input type="text" id="usercount" name="usercount" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">Admin Type</label>
                <select id="type" name="type" class="form-select" required>
                    <option value="BranchAdmin">Branch Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Add Admin</button>
        </form>
    </div>

    <div class="user-list">
        <h2 class="text-center">Existing Branch Admins</h2>
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Username</th>
                    <th>Company ID</th>
                    <th>User Count</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo $user['username']; ?></td>
                        <td><?php echo $user['companyId']; ?></td>
                        <td><?php echo $user['usercount']; ?></td>
                        <td>
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="delete_user" value="<?php echo $user['username']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
