<?php
// Include MongoDB library
require 'vendor/autoload.php'; // If you are using Composer

use MongoDB\Client;

// MongoDB connection
$server = "mongodb+srv://cadibal:Nevinotech512@cadibal.asets.mongodb.net/"; // MongoDB server URL
$dbname = "programming"; // MongoDB Database name

// Connect to the database
$client = new Client($server);
$database = $client->$dbname;
?>
