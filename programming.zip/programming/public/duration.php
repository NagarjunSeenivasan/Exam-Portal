<?php
session_start();

if (isset($_SESSION['duration'])) {
    echo json_encode(['success' => true, 'duration' => $_SESSION['duration']]); // Duration in minutes
} else {
    echo json_encode(['success' => false, 'message' => 'Duration not set']);
}
?>
