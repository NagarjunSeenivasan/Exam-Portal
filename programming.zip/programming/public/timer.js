function startTimer(duration, displayElementId, completeTestButtonId) {
    const timerKey = 'test_timer';
    let remainingTime = duration;

    // Check for existing timer state
    const savedTimer = localStorage.getItem(timerKey);
    if (savedTimer) {
        const { startTime, originalDuration } = JSON.parse(savedTimer);
        const elapsedTime = Math.floor((Date.now() - startTime) / 1000);
        remainingTime = Math.max(originalDuration - elapsedTime, 0);
    } else {
        localStorage.setItem(timerKey, JSON.stringify({ startTime: Date.now(), originalDuration: duration }));
    }

    const interval = setInterval(() => {
        const minutes = Math.floor(remainingTime / 60);
        const seconds = remainingTime % 60;
        document.getElementById(displayElementId).textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

        if (remainingTime <= 0) {
            clearInterval(interval);
            localStorage.removeItem(timerKey);
            showPopup();
        }
        

        remainingTime--;
    }, 1000);
}

// Automatically initialize the timer on page load
document.addEventListener('DOMContentLoaded', () => {
    const timerDisplayId = 'timerDisplay'; // Replace with the ID of your timer element
    const completeTestButtonId = 'completeTestButton'; // ID of the button to trigger
    fetch('duration.php') // Backend to fetch duration from the session
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const durationInSeconds = data.duration * 60; // Convert minutes to seconds
                startTimer(durationInSeconds, timerDisplayId, completeTestButtonId);
            } else {
                alert('Failed to fetch timer duration');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
});


function showPopup() {
    const popup = new bootstrap.Modal(document.getElementById('customPopup'));
    popup.show();

    // Redirect to the dashboard after 2 seconds
    setTimeout(() => {
        window.location.replace('../../mcq/user/dashboard.php');
    }, 3000);
}
// Complete Test Function to handle redirection
function completeTest() {
    // Show the Bootstrap modal using vanilla JavaScript
    var modal = new bootstrap.Modal(document.getElementById('completeTestModal'));
    modal.show();
}

// Redirect to dashboard after confirmation
function redirectToDashboard() {
    // Hide the modal using vanilla JavaScript before redirecting
    var modal = bootstrap.Modal.getInstance(document.getElementById('completeTestModal'));
    modal.hide();

    // Redirect to the dashboard
    window.location.replace('../../mcq/user/dashboard.php');
}
