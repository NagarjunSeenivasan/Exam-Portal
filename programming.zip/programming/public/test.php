<?php
// test.php
session_start();
require_once '../includes/connect.php';

$username = $_SESSION['username'];
$subject=$_SESSION['subject']  ;    // Store it in the session

if (isset($_GET['question_id'])) {
$question_id = $_GET['question_id'];
$_SESSION['question_id'] = $question_id; // Store it in the session


    // Fetch the question
    $question = $database->Questions->findOne(['questionid' => $question_id]);

    // Fetch test cases
    $test_cases = $database->TestCases->find(['questionid' => $question_id])->toArray();

    if ($question) {
        $question_text = $question['question_text'];
        $sample_input = $question['sample_input'];
        $sample_output = $question['sample_output'];
        $input_format = $question['input_format'];
        $output_format = $question['output_format'];
        $difficulty = $question['difficulty'];
        $question_type = $question['question_type'];
        $language = strtolower($question['language']); // Default language for the question
    } else {
        $question_text = "Question not found.";
        $sample_input = $sample_output = $language = "";
        $test_cases = [];
    }
} else {
    $question_text = "Invalid question.";
    $sample_input = $sample_output = $language = "";
    $test_cases = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coding Test Panel</title>
    <link rel="shortcut icon" href="../images/logo/logo.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
    <style>
                /* Global Variables */
                :root {
            --primary-color: #007bff;
            --secondary-color: #f8f9fa;
            --accent-color: #6c757d;
            --text-color-light: white;
            --text-color-dark: black;
            --timer-color: #dc3545;
            --answered-bg: #28a745;
            --unanswered-bg: #ffc107;
            --font-family: 'Poppins', sans-serif;
        }

        /* Global Styles */
        body {
            font-family: var(--font-family);
            background-color: var(--secondary-color);
            margin: 0;
            padding: 0;
        }

        /* Navbar Styling */
        .navbar {
            background-color: var(--primary-color);
        }

        .navbar-brand, .navbar-text {
            color: var(--text-color-light) !important;
        }

        .navbar-text {
            font-size: 0.9rem;
        }

        /* Timer Styling */
        .timer {
            font-size: 1rem;
            font-weight: bold;
            color: white;
            background: linear-gradient(45deg, #dc3545, #ff6f61);
            padding: 5px 10px;
            border-radius: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            display: inline-block;
            animation: pulse 1.5s infinite;
        }
        .tag {
        display: inline-block;
        margin-right: 5px;
        padding: 5px 10px;
        border-radius: 5px;
        font-size: 12px;
        color: white;
        }
        /* .tag-language {
        background-color: #007bff;
        }
        .tag-type {
        background-color: #28a745;
        } */
        .collapsible {
        background-color: #007bff;
        color: white;
        border: none;
        padding: 3px 7px;
        margin-top: 5px;
        margin-bottom: 5px;
        cursor: pointer;
        border-radius: 5px;
        }
        .hint-box {
        display: none;
        margin-top: 10px;
        background-color: #fbe9e7;
        padding: 10px;
        border-left: 5px solid #ff5722;
        }
        pre {
        background-color: #f5f5f5;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 5px;
        overflow: auto;
        }
        /* Spinner animation */
        .spinner {
            margin: auto;
            width: 40px;
            height: 40px;
            border: 4px solid #ccc;
            border-top-color: #007bff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        /* Keyframe for spin animation */
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        /* Modal styling */
        #test-results-modal {
            display: none;
            justify-content: center;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        #test-results-modal > div {
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            width: 80%;
            max-width: 500px;
            text-align: center;
            position: relative;
        }

        /* Close button */
        button {
            margin-top: 10px;
            padding: 6px 13.5px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Modal content container */
        #modal-test-results {
            display: none;
            max-height: 300px;
            overflow-y: auto;
        }

        /* Optional styling for modal content */
        .card {
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 4px;
            text-align: center;
        }
        @media(max-width:336px) 
        {
            .sub-res
            {
                margin-top: 5px !important;
            }
           
        }
    </style>

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">Test Portal</a>
            <span class="navbar-text">Welcome, <?php echo htmlspecialchars($username); ?> | Subject: <?php echo htmlspecialchars($subject); ?></span>
            <button id="completeTestButton" style="display:none;" onclick="completeTest()">Complete Test</button>
            <div class="timer">Time Remaining: <span id="timerDisplay"></span></div>
            <button onclick="submitResults()" style="margin-top: 0px;" class="btn btn-warning sub-res">Submit Results</button>

        </div>
    </nav>
<div style="display: flex; flex-wrap: wrap; gap: 20px; margin: 10px;">
    <!-- Question Section -->
    <div style="flex: 1; min-width: 300px; max-width: 35%; padding: 10px;">
  <h2 style="font-size: 20px; color: #333; margin-bottom: 15px; border-bottom: 2px solid #e3e3e3; padding-bottom: 10px;">
    <?php echo $question_id; ?>. Question
  </h2>
  <h3 id="question-title" style="font-size: 18px; color: #007bff; margin-bottom: 10px;">
    <?php echo $question_text ?: "Question not found."; ?>
  </h3>
  <p><strong>Input format:</strong> <?php echo $input_format; ?></p>
  <p><strong>Output format:</strong> <?php echo $output_format; ?></p>
  <p><strong>Level:</strong> <?php echo $difficulty; ?></p>

  <!-- Tags -->
  <div style="margin-top: 10px; margin-bottom:10px;">
    <span class="btn btn-info" style="padding: 2.5px 5px;"><?php echo $language; ?></span>
    <span class="btn btn-warning" style="padding: 2.5px 5px;"><?php echo $question_type; ?></span>
  </div>

  <!-- Sample Input -->
  <p style="margin-bottom:1px !important;"><strong>Sample Input:</strong></p>
  <button class="collapsible" style="padding: 2.5px 5px; font-size:15px;" onclick="toggleVisibility('input-box')">Show-Hide</button>
  <div id="input-box" style="display: none;">
    <pre><code class="language-text"><?php echo htmlspecialchars($sample_input); ?></code></pre>
  </div>

  <!-- Sample Output -->
  <p style="margin-bottom:1px !important;"><strong>Sample Output:</strong></p>
  <button class="collapsible" style="padding: 2.5px 5px; font-size:15px;" onclick="toggleVisibility('output-box')">Show-Hide</button>
  <div id="output-box" style="display: none;">
    <pre><code class="language-text"><?php echo htmlspecialchars($sample_output); ?></code></pre>
  </div>

  <!-- Hint Section -->
  <p style="margin-bottom:1px !important;"><strong>Hint:</strong></p>
  <button class="collapsible" style="padding: 2.5px 5px; font-size:15px;" onclick="toggleVisibility('hint-box')">Show-Hide</button>
  <div id="hint-box" class="hint-box">
    Nothing to display.
  </div>
</div>


    <!-- Code Editor and Testcase Section -->
    <div style="flex: 1; min-width: 300px; max-width: 60%;">
        <!-- Code Editor -->
        <div style=" padding: 2px; margin-bottom: 10px;">
            <!-- <h6 style="color: #333; margin-bottom: 10px;">Code Editor</h6> -->
            
            <div style="margin-top: 10px;">
                <label for="language-selector"><h6>Select Language:</h6></label>
                <select id="language-selector" style=" margin-top: 5px;" onchange="changeLanguage()">
                    <option value="python" <?php echo $language === 'python' ? 'selected' : ''; ?>>Python</option>
                    <option value="javascript" <?php echo $language === 'javascript' ? 'selected' : ''; ?>>JavaScript</option>
                    <option value="java" <?php echo $language === 'java' ? 'selected' : ''; ?>>Java</option>
                    <option value="c" <?php echo $language === 'c' ? 'selected' : ''; ?>>C</option>
                    <option value="cpp" <?php echo $language === 'cpp' ? 'selected' : ''; ?>>C++</option>
                </select>
            </div>
            <div id="editor" style="height: 350px; padding: 10px; overflow-y: auto; font-size:14.5px;"></div>
            <p id="muted-note" style="font-size: 10px; color: #6c757d; margin-top: 3px; margin-bottom:3px; text-align: center;">
               Important : Run test case before submitting the code.
            </p>
            <button class="btn btn-success" style="width: 30%; padding: 5px; font-size: 15px; border-radius: 6px; cursor: pointer;" onclick="submitCode()">Run Code</button>

        </div>
        <hr>
        <!-- live output -->
        <div>
            <h6 style="color: #333;">Live Execution <small>(Not required)</small></h6>
            <pre id="live-output" style="background: #000; color: #0f0; padding: 10px; max-height: 150px; overflow-y: auto;">No output yet.</pre>
        </div>
        <button class="btn btn-warning" style="width: 30%; padding: 5px; font-size: 15px; border-radius: 6px; cursor: pointer;" onclick="executeLiveCode()">Run Live</button>

<br>
        <!-- Submit Button and Testcase Results -->
        <div style=" padding: 10px;">
            <br>
            <h6 style="color: #333;"></h6>

            <div id="test-results" style="margin-top: 10px; max-height: 350px; overflow-y: auto;">
                <p class="text-warning text-center bg-dark" style="font-size: 13px;"></p>
            </div>
        </div>
    </div>
</div>

<div id="test-results-modal" style="display: none; justify-content: center; align-items: center; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0, 0, 0, 0.5); z-index: 1000;">
    <div style="background-color: #fff; padding: 5px; border-radius: 5px; width: 80%; max-width: 500px; text-align: center; position: relative;">
        <!-- Loader -->
        <div id="modal-loader" style="display: none; margin: 20px;">
            <div class="spinner"></div>
            <p>Processing your submission...</p>
        </div>

        <!-- Test Results -->
        <div id="modal-test-results" style="display: none; max-height: 300px; overflow-y: auto;"></div>

        <!-- Close Button -->
        <button onclick="closeModal()" style="margin-top: 10px; padding: 6px 12.5px; background-color: #007bff; color: #fff; border: none; border-radius: 4px; cursor: pointer;">
            Close
        </button>
    </div>
</div>

<!-- Bootstrap Modal -->
<div class="modal fade" id="customPopup" tabindex="-1" aria-labelledby="popupLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-primary" id="popupLabel">Time Over!</h5>
      </div>
      <div class="modal-body">
        Test completed successfully.
      </div>
    </div>
  </div>
</div>



<!-- Complete Test Button (Hidden Initially) -->
<!-- <button id="completeTestButton" style="display:none;" onclick="completeTest()" disabled>Complete Test</button> -->



<script>
    let editor = null;
    const testCases = <?php echo json_encode($test_cases); ?>;

    function initializeEditor() {
        editor = ace.edit("editor");
        editor.setTheme("ace/theme/monokai");
        editor.session.setMode("ace/mode/<?php echo $language; ?>");
    }

    function changeLanguage() {
        const language = document.getElementById('language-selector').value;
        const mode = getAceMode(language);
        editor.session.setMode("ace/mode/" + mode);
    }

    function getAceMode(language) {
        const modes = { python: "python", javascript: "javascript", java: "java", c: "c_cpp", cpp: "c_cpp" };
        return modes[language] || "python";
    }

    function submitCode() {
        const code = editor.getValue();
        if (!code) {
            alert("Please write some code before submitting.");
            return;
        }

        document.getElementById('test-results').innerHTML = ''; // Clear previous results

        testCases.forEach((testCase, index) => {
            const apiData = {
                source_code: code,
                language_id: getLanguageId(document.getElementById('language-selector').value),
                stdin: testCase.input_data,
                expected_output: testCase.expected_output
            };

            fetch('https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=false', {
                method: 'POST',
                headers: {
                    'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                    'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(apiData)
            })
            .then(response => response.json())
            .then(data => {
                const token = data.token;
                checkSubmission(token, index);
            })
            .catch(error => console.error('Error:', error));
        });
    }

    let testResults = []; // Store test results globally

function checkSubmission(token, index) {
    // Show loader
    showLoader();

    const pollSubmission = (resolve, reject) => {
        fetch(`https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=false`, {
            method: 'GET',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d' // Replace with your actual API key
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`API Error: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status.id <= 2) { // Status IDs: 1 = In Queue, 2 = Processing
                console.log("Submission still in progress...");
                setTimeout(() => pollSubmission(resolve, reject), 2000); // Poll every 2 seconds
            } else {
                resolve(data); // Submission is processed
            }
        })
        .catch(error => reject(error));
    };

    // Start polling
    new Promise(pollSubmission)
        .then(data => {
            // Hide loader and show results
            hideLoader();

            const result = document.createElement('div');
            result.classList.add('card', 'mt-3');

            let statusColor;
            switch (data.status.description) {
                case "Accepted":
                    statusColor = "#28a745"; // Green
                    break;
                case "Wrong Answer":
                    statusColor = "#dc3545"; // Red
                    break;
                default:
                    statusColor = "#ffc107"; // Yellow
            }

            const output = data.stdout || data.stderr || "No output available";

            result.innerHTML = `
                <table style="width: 100%; border-collapse: collapse; margin-top: 2px;">
                    <thead>
                        <tr>
                            <th style="border: 1px solid #ccc; padding: 1px; text-align: center;">Test Case</th>
                            <th style="border: 1px solid #ccc; padding: 1px; text-align: center;">Status</th>
                            <th style="border: 1px solid #ccc; padding: 1px; text-align: center;">Output</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="border: 1px solid #ccc; padding: 1px; text-align: center;">${index + 1}</td>
                            <td style="border: 1px solid #ccc; padding: 1px; text-align: center; color: ${statusColor};">${data.status.description}</td>
                            <td style="border: 1px solid #ccc; padding: 1px;"><pre>${output}</pre></td>
                        </tr>
                    </tbody>
                </table>
            `;

            // Append the result to the modal content
            document.getElementById('modal-test-results').appendChild(result);

            // Save the test result
            testResults.push({
                testCaseIndex: index + 1,
                status: data.status.description,
                output: output
            });

            // Show the modal
            openModal();
        })
        .catch(error => {
            // Hide loader and show error message
            hideLoader();

            console.error('Error:', error);
            const errorMessage = document.createElement('p');
            errorMessage.classList.add('text-danger', 'text-center');
            errorMessage.textContent = "An error occurred while fetching test case results.";
            document.getElementById('modal-test-results').appendChild(errorMessage);

            openModal();
        });
}

// Submit Results Function
function submitResults() {
    if (testResults.length === 0) {
        alert("Run test cases before submitting the results.");
        return;
    }

    fetch('submit_results.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ results: testResults })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Results submitted successfully!");
            testResults = []; // Clear results after submission
        } else {
            alert("Failed to submit results. Please try again.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("An error occurred while submitting results.");
    });
}

// Helper functions for showing/hiding loader and modal
// Show loader function
function showLoader() {
    document.getElementById('modal-loader').style.display = 'block'; // Show the loader
    document.getElementById('modal-test-results').style.display = 'none'; // Hide the results container
    setTimeout(() => {
        document.getElementById('test-results-modal').style.display = 'flex'; // Ensure modal is shown
    }, 100); // Delay slightly to show the modal
}

// Hide loader function
function hideLoader() {
    document.getElementById('modal-loader').style.display = 'none'; // Hide the loader
    document.getElementById('modal-test-results').style.display = 'block'; // Show the results container
}

// Open modal function
function openModal() {
    const modal = document.getElementById('test-results-modal');
    modal.style.display = 'flex';
}

// Close modal function
function closeModal() {
    const modal = document.getElementById('test-results-modal');
    modal.style.display = 'none';
    document.getElementById('modal-test-results').innerHTML = ''; // Clear previous results
}


    function executeLiveCode() {
        const code = editor.getValue();
        if (!code) {
            document.getElementById('live-output').textContent = 'Please write some code to execute.';
            return;
        }

        const stdin = ""; // Optional input data
        const languageId = getLanguageId(document.getElementById('language-selector').value);

        const apiData = {
            source_code: code,
            language_id: languageId,
            stdin: stdin,
        };

        document.getElementById('live-output').textContent = 'Executing code...';

        fetch('https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=false', {
            method: 'POST',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(apiData)
        })
        .then(response => response.json())
        .then(data => {
            const token = data.token;
            fetchLiveOutput(token);
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('live-output').textContent = 'Error while executing the code.';
        });
    }

    function fetchLiveOutput(token) {
        fetch(`https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=false`, {
            method: 'GET',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d'
            }
        })
        .then(response => response.json())
        .then(data => {
            const outputElement = document.getElementById('live-output');
            if (data.stdout) {
                outputElement.textContent = data.stdout;
                outputElement.style.color = '#0f0'; // Green for success
            } else if (data.stderr) {
                outputElement.textContent = `Error: ${data.stderr}`;
                outputElement.style.color = '#f00'; // Red for errors
            } else {
                outputElement.textContent = 'No output available.';
                outputElement.style.color = '#ffa500'; // Orange for no output
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('live-output').textContent = 'Error while fetching the output.';
        });
    }

    function getLanguageId(language) {
        const languages = { python: 71, javascript: 63, java: 62, c: 50, cpp: 54 };
        return languages[language] || 71;
    }

    window.onload = initializeEditor;
</script>

<script>
  function toggleVisibility(id) {
    const element = document.getElementById(id);
    element.style.display = element.style.display === 'none' ? 'block' : 'none';
  }
</script>
<!-- Include jQuery (make sure it’s loaded before Bootstrap JS) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Bootstrap CSS -->
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"> -->

<!-- Include Bootstrap JS (After jQuery) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script src="timer.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<!-- Bootstrap JS and CSS (Ensure Bootstrap is included) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

