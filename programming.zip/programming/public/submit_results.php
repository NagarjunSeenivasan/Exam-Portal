<?php
session_start(); // Start the session
require_once '../includes/connect.php';

// Decode JSON input (sent from the `submitResults` function)
$data = json_decode(file_get_contents('php://input'), true);

// Retrieve results from the request body
$results = $data['results'] ?? null;

// Retrieve session data
$username = $_SESSION['username'] ?? null;
$subject = $_SESSION['subject'] ?? null;
$question_id = $_SESSION['question_id'] ?? null;

// Validate input
if (!$results || !$username || !$subject) {
    echo json_encode(['success' => false, 'message' => 'Missing required data (results or session data)']);
    exit;
}

// Add session data to each result
foreach ($results as &$result) {
    $result['username'] = $username;
    $result['subject'] = $subject;
    $result['question_id'] = $question_id;
    $result['submitted_at'] = date('Y-m-d H:i:s'); // Add a timestamp
}

try {
    // Insert data into MongoDB
    $collection = $database->Submissions;
    $insertResult = $collection->insertMany($results);

    echo json_encode(['success' => true, 'insertedCount' => $insertResult->getInsertedCount()]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>
