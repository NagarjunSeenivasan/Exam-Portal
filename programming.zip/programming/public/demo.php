<?php
// test.php

if (isset($_GET['question_id'])) {
    $question_id = $_GET['question_id'];

    require_once '../includes/connect.php';

    // Fetch the question
    $question = $database->Questions->findOne(['questionid' => $question_id]);

    // Fetch test cases
    $test_cases = $database->TestCases->find(['questionid' => $question_id])->toArray();

    if ($question) {
        $question_text = $question['question_text'];
        $sample_input = $question['sample_input'];
        $sample_output = $question['sample_output'];
        $input_format = $question['input_format'];
        $output_format = $question['output_format'];
        $difficulty = $question['difficulty'];
        $language = strtolower($question['language']); // Default language for the question
    } else {
        $question_text = "Question not found.";
        $sample_input = $sample_output = $language = "";
        $test_cases = [];
    }
} else {
    $question_text = "Invalid question.";
    $sample_input = $sample_output = $language = "";
    $test_cases = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coding Test Panel</title>
    <link rel="shortcut icon" href="../images/logo/logo.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
    <style>
        body {
            background-color: #f8f9fa;
            font-family: poppins !important;
        }


    </style>
</head>
<body>
<div style="display: flex; flex-wrap: wrap; gap: 20px; margin: 10px;">
    <!-- Question Section -->
    <div style="flex: 1; min-width: 300px; max-width: 35%; padding: 10px; ">
        <h2 style="font-size: 20px; color: #333; margin-bottom: 15px; border-bottom: 2px solid #e3e3e3; padding-bottom: 10px;"><?php echo $question_id?>.Question</h2>
        <h3 id="question-title" style="font-size: 18px; color: #007bff; margin-bottom: 10px;">
            <?php echo $question_text ?: "Question not found."; ?>
        </h3>
        <p><strong>Input format:</strong> <?php echo $input_format; ?></p>
        <p><strong>Output format:</strong> <?php echo $output_format; ?></p>
        <p><strong>Difficulty:</strong> <?php echo $difficulty; ?></p>
        <p><strong>Sample Input:</strong> <?php echo $sample_input; ?></p>
        <p><strong>Sample Output:</strong> <?php echo $sample_output; ?></p>
    </div>

    <!-- Code Editor and Testcase Section -->
    <div style="flex: 1; min-width: 300px; max-width: 60%;">
        <!-- Code Editor -->
        <div style=" padding: 2px; margin-bottom: 20px;">
            <!-- <h6 style="color: #333; margin-bottom: 10px;">Code Editor</h6> -->
            
            <div style="margin-top: 10px;">
                <label for="language-selector"><h6>Select Language:</h6></label>
                <select id="language-selector" style=" margin-top: 5px;" onchange="changeLanguage()">
                    <option value="python" <?php echo $language === 'python' ? 'selected' : ''; ?>>Python</option>
                    <option value="javascript" <?php echo $language === 'javascript' ? 'selected' : ''; ?>>JavaScript</option>
                    <option value="java" <?php echo $language === 'java' ? 'selected' : ''; ?>>Java</option>
                    <option value="c" <?php echo $language === 'c' ? 'selected' : ''; ?>>C</option>
                    <option value="cpp" <?php echo $language === 'cpp' ? 'selected' : ''; ?>>C++</option>
                </select>
            </div><div id="editor" style="height: 300px; padding: 10px; overflow-y: auto; font-size:15px;"></div>
        </div>
        <!-- live output -->
        <div>
            <h6 style="color: #333;">Live Execution Output</h6>
            <pre id="live-output" style="background: #000; color: #0f0; padding: 10px; max-height: 150px; overflow-y: auto;">No output yet.</pre>
        </div>
        <button class="btn btn-success" style="width: 30%; padding: 5px; font-size: 15px; border-radius: 6px; cursor: pointer;" onclick="executeLiveCode()">Run Live</button>
        <button class="btn btn-danger" style="width: 30%; padding: 5px; font-size: 15px; border-radius: 6px; cursor: pointer;" onclick="submitCode()">Submit</button>

<br>
        <!-- Submit Button and Testcase Results -->
        <div style=" padding: 10px;">
            <br>
            <h6 style="color: #333;">Test Results:</h6>

            <div id="test-results" style="margin-top: 10px; max-height: 150px; overflow-y: auto;">
                <p class="text-warning text-center bg-dark" style="font-size: 13px;">Test case results will be appended here</p>
            </div>
        </div>
    </div>
</div>




<script>
    let editor = null;
    const testCases = <?php echo json_encode($test_cases); ?>;

    function initializeEditor() {
        editor = ace.edit("editor");
        editor.setTheme("ace/theme/monokai");
        editor.session.setMode("ace/mode/<?php echo $language; ?>");
    }

    function changeLanguage() {
        const language = document.getElementById('language-selector').value;
        const mode = getAceMode(language);
        editor.session.setMode("ace/mode/" + mode);
    }

    function getAceMode(language) {
        const modes = { python: "python", javascript: "javascript", java: "java", c: "c_cpp", cpp: "c_cpp" };
        return modes[language] || "python";
    }

    function submitCode() {
        const code = editor.getValue();
        if (!code) {
            alert("Please write some code before submitting.");
            return;
        }

        document.getElementById('test-results').innerHTML = ''; // Clear previous results

        testCases.forEach((testCase, index) => {
            const apiData = {
                source_code: code,
                language_id: getLanguageId(document.getElementById('language-selector').value),
                stdin: testCase.input_data,
                expected_output: testCase.expected_output
            };

            fetch('https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=false', {
                method: 'POST',
                headers: {
                    'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                    'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(apiData)
            })
            .then(response => response.json())
            .then(data => {
                const token = data.token;
                checkSubmission(token, index);
            })
            .catch(error => console.error('Error:', error));
        });
    }

    function checkSubmission(token, index) {
        fetch(`https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=false`, {
            method: 'GET',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d'
            }
        })
        .then(response => response.json())
        .then(data => {
            const result = document.createElement('div');
            result.classList.add('card', 'mt-3');

            let statusColor;
            if (data.status.description === "Accepted") {
                statusColor = "#28a745"; // Green for success
            } else if (data.status.description === "Wrong Answer") {
                statusColor = "#dc3545"; // Red for wrong answer
            } else {
                statusColor = "#ffc107"; // Yellow for other statuses
            }

            result.innerHTML = `
            <table style="width: 100%; border-collapse: collapse; margin-top: 5px;">
                <thead>
                    <tr>
                        <th style="border: 1px solid #ccc; padding: 4px; text-align: center;">Test Case</th>
                        <th style="border: 1px solid #ccc; padding: 4px; text-align: center;">Status</th>
                        <th style="border: 1px solid #ccc; padding: 4px; text-align: center;">Output</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="border: 1px solid #ccc; padding: 4px; text-align: center;">${index + 1}</td>
                        <td style="border: 1px solid #ccc; padding: 4px; text-align: center; color: ${statusColor};">${data.status.description}</td>
                        <td style="border: 1px solid #ccc; padding: 4px;"><pre>${data.stdout || data.stderr}</pre></td>
                    </tr>
                </tbody>
            </table>
        `;


            document.getElementById('test-results').appendChild(result);
        })
        .catch(error => console.error('Error:', error));
    }

    function executeLiveCode() {
        const code = editor.getValue();
        if (!code) {
            document.getElementById('live-output').textContent = 'Please write some code to execute.';
            return;
        }

        const stdin = ""; // Optional input data
        const languageId = getLanguageId(document.getElementById('language-selector').value);

        const apiData = {
            source_code: code,
            language_id: languageId,
            stdin: stdin,
        };

        document.getElementById('live-output').textContent = 'Executing code...';

        fetch('https://judge0-ce.p.rapidapi.com/submissions?base64_encoded=false', {
            method: 'POST',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(apiData)
        })
        .then(response => response.json())
        .then(data => {
            const token = data.token;
            fetchLiveOutput(token);
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('live-output').textContent = 'Error while executing the code.';
        });
    }

    function fetchLiveOutput(token) {
        fetch(`https://judge0-ce.p.rapidapi.com/submissions/${token}?base64_encoded=false`, {
            method: 'GET',
            headers: {
                'x-rapidapi-host': 'judge0-ce.p.rapidapi.com',
                'x-rapidapi-key': '17074e71f1mshce13f631cf66f57p1090adjsn9b0b8bd1c75d'
            }
        })
        .then(response => response.json())
        .then(data => {
            const outputElement = document.getElementById('live-output');
            if (data.stdout) {
                outputElement.textContent = data.stdout;
                outputElement.style.color = '#0f0'; // Green for success
            } else if (data.stderr) {
                outputElement.textContent = `Error: ${data.stderr}`;
                outputElement.style.color = '#f00'; // Red for errors
            } else {
                outputElement.textContent = 'No output available.';
                outputElement.style.color = '#ffa500'; // Orange for no output
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('live-output').textContent = 'Error while fetching the output.';
        });
    }

    function getLanguageId(language) {
        const languages = { python: 71, javascript: 63, java: 62, c: 50, cpp: 54 };
        return languages[language] || 71;
    }

    window.onload = initializeEditor;
</script>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

