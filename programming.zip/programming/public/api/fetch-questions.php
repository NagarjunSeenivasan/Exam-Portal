<?php
// Include your MongoDB connection
require_once '../../includes/connect.php';

// Start the session (assuming companyId and subject are stored in session)
session_start();

// Retrieve session values
$companyId = $_SESSION['companyId'];
$subject=$_SESSION['subject']  ;    // Store it in the session



// Ensure session data exists
if (empty($companyId) || empty($subject)) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Missing session data']);
    exit;
}

// Step 1: Fetch TestAllocations for the given companyId and subject
$testAllocationsQuery = $database->TestAllocations->findOne([
    'companyId' => $companyId,
    'subject' => $subject
]);

if (!$testAllocationsQuery) {
    http_response_code(404); // Not Found
    echo json_encode(['error' => 'No TestAllocations found for the given companyId and subject']);
    exit;
}

// Step 2: Fetch question IDs from Assignments
$assignmentsQuery = $database->Assignments->find([
    'companyId' => $companyId,
    'subject' => $subject,
]);

$questionIds = [];
foreach ($assignmentsQuery as $assignment) {
    if (isset($assignment['questionid'])) {
        $questionIds[] = $assignment['questionid'];
    }
}

// Step 3: Fetch questions from Questions collection matching the question IDs
$questionsQuery = $database->Questions->find([
    'questionid' => ['$in' => $questionIds],
]);

// Prepare the questions array
$questions = [];
foreach ($questionsQuery as $question) {
    $questions[] = [
        'question_id' => $question['questionid'],
        'question_text' => $question['question_text'],
        'language' => $question['language'],
        'difficulty' => $question['difficulty'],
        'input_format' => $question['input_format'],
        'output_format' => $question['output_format'],
        'sample_input' => $question['sample_input'],
        'sample_output' => $question['sample_output'],
    ];
}

// Set the response content type to JSON
header('Content-Type: application/json');

// Return the filtered questions as a JSON response
echo json_encode($questions);
?>
