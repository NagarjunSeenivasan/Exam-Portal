<?php
session_start();
session_destroy(); // Destroy session data
header("Location: ../../mcq/user/"); // Redirect to login page
exit();
?>
