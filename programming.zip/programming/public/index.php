<?php 
session_start();

include '../includes/connect.php';
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../../mcq/logout.php");
    exit;
}


if (isset($_GET['subject'])) {
    $subject = urldecode($_GET['subject']); // Decode the subject from URL encoding
    $_SESSION['subject'] = $subject;       // Store it in the session
} else {
    echo "Subject not found in the URL.";
}

// $subject = $_POST['subject'] ?? null;

if ($subject) {
    // $_SESSION['subject'] = $subject;

    // Fetch duration from TestAllocations collection
    $collection = $database->TestAllocations;
    $allocation = $collection->findOne(['subject' => $subject]);

    if ($allocation && isset($allocation['duration'])) {
        $_SESSION['duration'] = $allocation['duration']; // Store duration in session
        // echo json_encode(['success' => true, 'duration' => $allocation['duration']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Duration not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Subject not provided']);
}



// Retrieve session data
$username = $_SESSION['username'];

$companyId = $_SESSION['companyId'];
$department = $_SESSION['department'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coding Test Portal</title>
    <link rel="shortcut icon" href="../images/logo/logo.png" type="image/x-icon">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Global Variables */
        :root {
            --primary-color: #007bff;
            --secondary-color: #f8f9fa;
            --accent-color: #6c757d;
            --text-color-light: white;
            --text-color-dark: black;
            --timer-color: #dc3545;
            --answered-bg: #28a745;
            --unanswered-bg: #ffc107;
            --font-family: 'Poppins', sans-serif;
        }

        /* Global Styles */
        body {
            font-family: var(--font-family);
            background-color: var(--secondary-color);
            margin: 0;
            padding: 0;
        }

        /* Navbar Styling */
        .navbar {
            background-color: var(--primary-color);
        }

        .navbar-brand, .navbar-text {
            color: var(--text-color-light) !important;
        }

        .navbar-text {
            font-size: 0.9rem;
        }

        /* Timer Styling */
        .timer{
            font-size: 1rem;
            font-weight: bold;
            color: white;
            background: linear-gradient(45deg, #dc3545, #ff6f61);
            padding: 5px 10px;
            border-radius: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            display: inline-block;
            animation: pulse 1.5s infinite;
        }
        /* Question style */
        .question-item {
            background: #ffffff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .question-item h4 {
            font-size: 1.25rem;
            color: #343a40;
        }
        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        .btn-custom:hover {
            background-color: #0056b3;
            color: white;
        }
        footer {
            position: fixed;
            bottom: 0;
            width: 100%;
            background: #ff914d;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
        footer p {
            margin: 0;
            font-size: 0.9rem;
        }
        @media (max-width: 400px) {
            .dropdown-menu
            {
                right: auto !important;
                left: 0px !important;
            }
        }
    </style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js"></script>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="#">Test Portal</a>
            <span class="navbar-text">Welcome, <?php echo htmlspecialchars($username); ?> | Subject: <?php echo htmlspecialchars($subject); ?></span>
            <div class="timer">Time Remaining: <span id="timerDisplay"></span></div>
            <button id="completeTestButton" class="btn btn-danger" onclick="completeTest()"><b>Complete Test</b></button>

        </div>
    </nav>
    <br>


<!-- Bootstrap Modal -->
<div class="modal fade" id="completeTestModal" tabindex="-1" aria-labelledby="completeTestModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="completeTestModalLabel">Test Completed</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Do you want to submit your results and complete the test?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" onclick="redirectToDashboard()">Submit</button>
            </div>
        </div>
    </div>
</div>

<!-- Complete Test Button (Hidden Initially) -->
<!-- <button id="completeTestButton" style="display:none;" onclick="completeTest()" disabled>Complete Test</button> -->
<!-- Bootstrap Modal -->
<div class="modal fade" id="customPopup" tabindex="-1" aria-labelledby="popupLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-primary" id="popupLabel">Time Over!</h5>
      </div>
      <div class="modal-body">
        Test completed successfully.
      </div>
    </div>
  </div>
</div>



<br>
    <div class="container">
        <div id="questions-list">
            <!-- Questions will load dynamically here -->
        </div>
    </div>
<br>
<br>

<!-- Bootstrap Modal for Popup Confirmation -->
<div class="modal fade" id="confirmStartTestModal" tabindex="-1" aria-labelledby="confirmStartTestModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmStartTestModalLabel">Start Test?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to start the test?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="confirmStartTestBtn">Continue</button>
      </div>
    </div>
  </div>
</div>

<!-- Warning Modal for Fullscreen Exit -->
<div class="modal fade" id="fullscreenWarningModal" tabindex="-1" aria-labelledby="fullscreenWarningModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="fullscreenWarningModalLabel">Warning</h5>
      </div>
      <div class="modal-body">
        You are not allowed to exit fullscreen. Please click "Continue" to resume the test.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="resumeFullscreenBtn">Continue</button>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap Modal for Popup Confirmation -->
<div class="modal fade" id="confirmStartTestModal" tabindex="-1" aria-labelledby="confirmStartTestModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="confirmStartTestModalLabel">Start Test?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to start the test?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="confirmStartTestBtn">Continue</button>
      </div>
    </div>
  </div>
</div>

<!-- Warning Modal for Fullscreen Exit -->
<div class="modal fade" id="fullscreenWarningModal" tabindex="-1" aria-labelledby="fullscreenWarningModalLabel" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="fullscreenWarningModalLabel">Warning</h5>
      </div>
      <div class="modal-body">
        You are not allowed to exit fullscreen. Please click "Continue" to resume the test.
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="resumeFullscreenBtn">Continue</button>
      </div>
    </div>
  </div>
</div>

<script>
    // Function to request fullscreen mode
    function enterFullscreen() {
        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen();
        } else if (document.documentElement.webkitRequestFullscreen) { // Safari
            document.documentElement.webkitRequestFullscreen();
        } else if (document.documentElement.msRequestFullscreen) { // IE/Edge
            document.documentElement.msRequestFullscreen();
        }
    }

    // Wait for the page to load and show the confirmation popup
    window.onload = function() {
        // Show the confirmation popup automatically on page load
        setTimeout(() => {
            $('#confirmStartTestModal').modal('show');
        }, 500); // You can adjust the delay time if needed
    };

    // When the "OK" button in the confirmation popup is clicked, trigger fullscreen
    document.getElementById('confirmStartTestBtn').addEventListener('click', function() {
        // Close the modal
        $('#confirmStartTestModal').modal('hide');
        
        // Trigger fullscreen mode
        enterFullscreen();
    });

    // Handle Escape key press (to block exiting fullscreen)
    document.addEventListener('keydown', function(event) {
        if (event.key === "Escape") {
            // If in fullscreen mode and Escape is pressed, show warning modal
            if (document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement) {
                // Show warning modal and prevent the default escape action
                event.preventDefault();  // Prevent the default exit fullscreen action
                $('#fullscreenWarningModal').modal('show');
            }
        }
    });

    // Listen for fullscreenchange to detect when fullscreen is exited manually
    document.addEventListener('fullscreenchange', function() {
        if (!document.fullscreenElement) {
            // If fullscreen is exited, show the warning modal
            $('#fullscreenWarningModal').modal('show');
        }
    });

    // When the user clicks "Continue" in the warning modal, re-enable fullscreen
    document.getElementById('resumeFullscreenBtn').addEventListener('click', function() {
        $('#fullscreenWarningModal').modal('hide'); // Close the warning modal
        enterFullscreen(); // Re-enter fullscreen
    });
</script>

<!-- Include jQuery (make sure it’s loaded before Bootstrap JS) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Footer -->
    <!-- <footer>
        <p>&copy; <span id="year"></span> CADIBAL. All rights reserved.</p>
    </footer> -->

    <script>
        // document.getElementById("year").textContent = new Date().getFullYear();

        function fetchQuestions() {
            fetch('api/fetch-questions.php')
                .then(response => response.json())
                .then(data => {
                    const questionsList = document.getElementById('questions-list');
                    questionsList.innerHTML = ""; 

                    if (data.length > 0) {
                        data.forEach(question => {
                            const questionElement = document.createElement('div');
                            questionElement.classList.add('question-item');
                            
                            questionElement.innerHTML = `
                            <div class="table-responsive">
                                <table class="table table-bordered table-hover">
                                    <thead class="table-light">
                                        <tr>
                                            <th style="width: 60%;">Question</th>
                                            <th style="width: 20%; text-align: center;">Difficulty</th>
                                            <th style="width: 20%; text-align: center;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td style="padding-left: 15px;">${question.question_text}</td>
                                            <td style="text-align: center;">
                                                <span class="badge ${getDifficultyClass(question.difficulty)}">${question.difficulty}</span>
                                            </td>
                                            <td style="text-align: center;">
                                                <a href="test.php?question_id=${question.question_id}" class="btn btn-custom btn-sm">
                                                    Start Test
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        `;

                // Helper function to assign a class based on difficulty
                function getDifficultyClass(difficulty) {
                    switch (difficulty.toLowerCase()) {
                        case 'easy':
                            return 'bg-success text-white'; // Green for easy
                        case 'medium':
                            return 'bg-warning text-dark'; // Yellow for medium
                        case 'hard':
                            return 'bg-danger text-white'; // Red for hard
                        default:
                            return 'bg-secondary text-white'; // Grey for unknown
                    }
                }


                            questionsList.appendChild(questionElement);
                        });
                    } else {
                        questionsList.innerHTML = "<p class='text-center'>No questions available.</p>";
                    }
                })
                .catch(error => {
                    console.error('Error fetching questions:', error);
                    alert("Error fetching the questions.");
                });
        }

        fetchQuestions();
    </script>
    <!-- <footer>
        <p>&copy; <span id="year"></span> CADIBAL. All rights reserved.</p>
    </footer> -->

    <!-- Include jQuery (make sure it’s loaded before Bootstrap JS) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Bootstrap CSS -->
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"> -->

<!-- Include Bootstrap JS (After jQuery) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script src="timer.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>



</body>
</html>
