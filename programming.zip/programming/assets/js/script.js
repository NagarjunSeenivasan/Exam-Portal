// Function to fetch questions from the backend and display them
function fetchQuestions() {
    fetch('../../public/api/fetch-questions.php') // Replace with the actual path
        .then(response => response.json())
        .then(data => {
            const questionsList = document.getElementById('questions-list');
            questionsList.innerHTML = ''; // Clear the list

            // Iterate over the questions and display them
            data.forEach(question => {
                const questionElement = document.createElement('div');
                questionElement.innerHTML = `
                    <div>
                        <h4>${question.question_text}</h4>
                        <button onclick="loadQuestion('${question.question_id}')">Start Test</button>
                    </div>
                `;
                questionsList.appendChild(questionElement);
            });
        })
        .catch(error => console.error('Error fetching questions:', error));
}

window.onload = fetchQuestions;
